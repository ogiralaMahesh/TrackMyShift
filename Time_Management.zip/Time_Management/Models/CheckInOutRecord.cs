﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Time_Management.Models
{
    public class CheckInOutRecord
    {
        public int Id { get; set; }
        public string EmployeeId { get; set; }
        public DateTime CheckIn { get; set; }
        public DateTime? CheckOut { get; set; }
        public decimal? TotalHours { get; set; }
    }
}