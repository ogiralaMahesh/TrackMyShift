﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Time_Management.Models
{
    public class EmployeeTimings
    {
        public string full_name { get; set; }
        public DateTime LoginDate { get; set; }
        public DateTime CheckInTime { get; set; }
        public DateTime CheckOutTime { get; set; }
        public TimeSpan TotalHoursWorked { get; set; }
        public string SelectedDate { get; set; }
        public bool CheckInStatus { get; set; }
    }
}