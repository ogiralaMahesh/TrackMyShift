﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Time_Management.Models
{
    public class IndexViewModel
    {
        public string UserName { get; set; }
        public bool IsCheckedIn { get; set; }
        public bool IsCheckedOut { get; set; }
    }
}