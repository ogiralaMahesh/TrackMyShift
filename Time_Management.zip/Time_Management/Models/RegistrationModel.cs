﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Time_Management.Models
{
    public class RegistrationModel
    {   public string Full_Name { get; set; }
        public string UserName { get; set; }
        public string SmartGigMailId { get; set; }
        public string EmployeeId { get; set; }
        public string ConfirmEmployeeId { get; set; }
    }
}