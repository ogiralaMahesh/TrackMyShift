﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Time_Management.Models;

namespace Time_Management.Controllers
{
    
    public class AdminController : Controller
    {
        private readonly string connectionString = "Server=tcp:3.6.73.110, 1433;Database=PI_Testing;User Id=dbdevuser;Password=Sql2020";
        private string date;

        // GET: Admin
        [HttpGet]
        public ActionResult Admin()
        {
            var employeeAttendanceList = new List<EmployeeTimings>();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
          

                    string query = "SELECT full_name, LoginDate, CheckInTime, CheckOutTime, TotalHoursWorked FROM EmployeeTimings4";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var employeeAttendance = new EmployeeTimings();
                                employeeAttendance.full_name = reader.IsDBNull(0) ? null : reader.GetString(0);
                                employeeAttendance.LoginDate = reader.IsDBNull(1) ? default(DateTime) : reader.GetDateTime(1);
                                employeeAttendance.CheckInTime = reader.IsDBNull(2) ? default(DateTime) : reader.GetDateTime(2);
                                employeeAttendance.CheckOutTime = reader.IsDBNull(3) ? default(DateTime) : reader.GetDateTime(3);
                                employeeAttendance.TotalHoursWorked = reader.IsDBNull(4) ? default(TimeSpan) : reader.GetTimeSpan(4);
                                employeeAttendanceList.Add(employeeAttendance);
                            }
                            
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle the exception here, for example by logging it or displaying an error message to the user
                ViewBag.ErrorMessage = "An error occurred while retrieving employee attendance data: " + ex.Message;
            }
            
            return View(employeeAttendanceList);
        }

        [HttpGet]
        public ActionResult FilterByDate(DateTime? SelectedDate, EmployeeTimings ET)
        {
            var employeeAttendanceList = new List<EmployeeTimings>();
            try
            {
                string userName = (string)Session["UserName"];
                ViewBag.UserName = userName;
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    if (SelectedDate == null)
                    {
                        // Set a default value if SelectedDate is null
                        SelectedDate = DateTime.Today;
                    }
                    DateTime selectedDate = SelectedDate.Value.Date;
                    string query = "SELECT full_name, LoginDate, CheckInTime, CheckOutTime, TotalHoursWorked FROM EmployeeTimings4 WHERE LoginDate = '" + selectedDate.ToString("yyyy-MM-dd") + "'";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var employeeAttendance = new EmployeeTimings();
                                employeeAttendance.full_name = reader.IsDBNull(0) ? null : reader.GetString(0);
                                employeeAttendance.LoginDate = reader.IsDBNull(1) ? default(DateTime) : reader.GetDateTime(1);
                                employeeAttendance.CheckInTime = reader.IsDBNull(2) ? default(DateTime) : reader.GetDateTime(2);
                                employeeAttendance.CheckOutTime = reader.IsDBNull(3) ? default(DateTime) : reader.GetDateTime(3);
                                employeeAttendance.TotalHoursWorked = reader.IsDBNull(4) ? default(TimeSpan) : reader.GetTimeSpan(4);
                                employeeAttendanceList.Add(employeeAttendance);
                            }
                        }
                    }
                }
                if (employeeAttendanceList.Count == 0)
                {
                    // The user hasn't checked in for the selected date
                    ViewBag.CheckInMessage = "You haven't checked in yet for the selected date.";
                }
                else
                {
                    // The user has already checked in for the selected date
                    ViewBag.CheckInMessage = "You have already checked in for the selected date.";
                }
                return View("Admin", employeeAttendanceList);
            }
            catch (Exception ex)
            {
                // Handle the exception here, for example by logging it or displaying an error message to the user
                ViewBag.ErrorMessage = "An error occurred while retrieving employee attendance data: " + ex.Message;
                return View("Admin");
            }

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Logout()
        {
            // Clear the user's session and redirect to the login page
            Session.Clear();
            return RedirectToAction("Index", "MainPage");
        }
        [HttpGet]
        public ActionResult FilterByName()
        {
            var fullNames = new List<string>();

            string query = "SELECT DISTINCT full_name FROM EmployeeTimings4";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    string fullName = reader.IsDBNull(0) ? null : reader.GetString(0);
                    fullNames.Add(fullName);
                }
            }

            ViewBag.FullNames = new SelectList(fullNames);

            return View(ViewBag.FullNames);
        }
    }
}