﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using Time_Management.Models;

namespace Time_Management.Controllers
{
    public class RegistrationController : Controller
    {
        private readonly string connectionString = "Server=tcp:3.6.73.110, 1433;Database=PI_Testing;User Id=dbdevuser;Password=Sql2020";

        // GET: Registration
        public ActionResult Registration()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(RegistrationModel model)
        {
            try
            {
                // Step 3: Connect to the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Step 4: Save the data
                    string query = "INSERT INTO RegistrationModel (Full_Name,UserName, SmartGigMailId, EmployeeId, ConfirmEmployeeId) VALUES (@Full_Name,@UserName, @SmartGigMailId, @EmployeeId, @ConfirmEmployeeId)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Full_Name", model.Full_Name);
                    command.Parameters.AddWithValue("@UserName", model.UserName);
                    command.Parameters.AddWithValue("@SmartGigMailId", model.SmartGigMailId);
                    command.Parameters.AddWithValue("@EmployeeId", model.EmployeeId);
                    command.Parameters.AddWithValue("@ConfirmEmployeeId", model.ConfirmEmployeeId);
                    command.ExecuteNonQuery();
                }
                TempData["SuccessMessage"] = "Data has been successfully saved to the database!";
                return RedirectToAction("Registration", "Registration");

                
            }
            catch (Exception ex)
            {
                ViewBag.Error = "An error occurred while processing your request. Please try again later.";
                return View("Error");
            }
        }
    }
}
