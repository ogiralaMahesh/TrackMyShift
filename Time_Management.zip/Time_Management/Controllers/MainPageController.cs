﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Time_Management.Controllers
{
    public class MainPageController : Controller
    {
        // GET: MainPage
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult AdminLogin()
        {
            return RedirectToAction("Index1","Default");
        }
        public ActionResult UserLogin()
        {
            return RedirectToAction("Index", "Login");
        }
    }
}