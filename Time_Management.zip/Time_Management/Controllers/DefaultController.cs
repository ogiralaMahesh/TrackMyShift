﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Configuration;
using Time_Management.Models;

namespace Time_Management.Controllers
{
    public class DefaultController : Controller
    {
        private readonly string connectionString = "Server=tcp:3.6.73.110, 1433;Database=PI_Testing;User Id=dbdevuser;Password=Sql2020";

        // GET: Login
        public ActionResult Index1()
        {
            return View();
        }
        public ActionResult Logout1()
        {
            // Clear the user's session or authentication cookie here
            // Redirect the user to the login page
            return RedirectToAction("Index", "Login");
        }

        [HttpPost]
        public ActionResult Authenticate1(UserCredentials credentials)
        {
            try
            {
                // Check if username and password are valid
                bool isValid = false;
                string userName = string.Empty;


                if (!string.IsNullOrEmpty(credentials.Username) && !string.IsNullOrEmpty(credentials.Password))
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM Admin WHERE Username=@Username AND Password=@Password", connection);
                        command.Parameters.AddWithValue("@Username", credentials.Username);
                        command.Parameters.AddWithValue("@Password", credentials.Password);
                        int count = (int)command.ExecuteScalar();

                        isValid = (count == 1);

                        if (isValid)
                        {
                            // Get the username from the database and store it in session
                            SqlCommand userNameCommand = new SqlCommand("SELECT Username FROM UserCredentials WHERE Username=@Username AND Password=@Password", connection);

                            userNameCommand.Parameters.AddWithValue("@Username", credentials.Username);
                            userNameCommand.Parameters.AddWithValue("@Password", credentials.Password);
                            userName = (string)userNameCommand.ExecuteScalar();

                            Session["UserName"] = userName;


                        }
                    }
                }

                // Redirect to appropriate page
                if (isValid)
                {
                    return RedirectToAction("Admin", "Admin");
                }
                else
                {
                    ViewBag.ErrorMessage = "Invalid username or password";
                    return View("Index1");
                }
            }
            catch (Exception ex)
            {
                // Handle the exception
                ViewBag.ErrorMessage = "Both fields are required.";
                // Log the exception using a logging framework such as log4net
                return View("Index1");
            }
        }


    }

}
