﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Time_Management.Controllers
{
    public class PracticeController : Controller
    {
        // GET: Practice
        
      
            public ActionResult Index()
            {
                var isCheckedIn = Request.Cookies["isCheckedIn"]?.Value ?? "";
                ViewBag.IsCheckedIn = isCheckedIn == "true";
                return View();
            }

           
        
    }
}