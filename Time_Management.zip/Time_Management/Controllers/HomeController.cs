﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using Time_Management.Models;
namespace WebApplication27.Controllers
{
  
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            string userName = (string)Session["UserName"];
            ViewBag.UserName = userName;
            bool isCheckedIn = false;
            bool isCheckedOut = false;
            string connectionString = "Server = tcp:3.6.73.110, 1433; Database = PI_Testing; User Id = dbdevuser; Password = Sql2020";
            var employeeAttendanceList = new List<EmployeeTimings>();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT CheckInTime, CheckOutTime FROM EmployeeTimings4 WHERE full_name = @UserName AND CheckOutTime IS NULL";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserName", userName);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                isCheckedIn = reader.IsDBNull(0) == false;
                                isCheckedOut = reader.IsDBNull(1) == false;
                            }
                            while (reader.Read())
                            {
                                var employeeAttendance = new EmployeeTimings();
                                employeeAttendance.full_name = reader.IsDBNull(0) ? null : reader.GetString(0);
                                employeeAttendance.LoginDate = reader.IsDBNull(1) ? default(DateTime) : reader.GetDateTime(1);
                                employeeAttendance.CheckInTime = reader.IsDBNull(2) ? default(DateTime) : reader.GetDateTime(2);
                                employeeAttendance.CheckOutTime = reader.IsDBNull(3) ? default(DateTime) : reader.GetDateTime(3);
                                employeeAttendance.TotalHoursWorked = reader.IsDBNull(4) ? default(TimeSpan) : reader.GetTimeSpan(4);
                                employeeAttendanceList.Add(employeeAttendance);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle the exception here, e.g. log it or show an error message to the user
                // For example, you can show an error message to the user like this:
                ModelState.AddModelError("", "An error occurred while retrieving the check-in/out state. Please try again later.");
            }

            // Create a view model to pass the state of the buttons to the view
            var model = new IndexViewModel
            {
                UserName = userName,
                IsCheckedIn = isCheckedIn,
                IsCheckedOut = isCheckedOut
            };

            return View(model);
        }

        [HttpPost]
        
        public ActionResult SaveCheckedInTime(Employee emp)
        {
            string userName = (string)Session["UserName"];
            DateTime checkInTime = DateTime.Now;

            string connectionString = "Server = tcp:3.6.73.110, 1433; Database = PI_Testing; User Id = dbdevuser; Password = Sql2020";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO EmployeeTimings4(full_name,CheckInTime) VALUES (@UserName,@CheckInTime)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserName", userName);
                        command.Parameters.AddWithValue("@CheckInTime", checkInTime);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle the exception here, e.g. log it or show an error message to the user
                // For example, you can show an error message to the user like this:
                ModelState.AddModelError("", "An error occurred while saving the check-in time. Please try again later.");
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult SaveCheckedOutTime()
        {
            string userName = (string)Session["UserName"];
            DateTime checkInTime = DateTime.MinValue;

            string connectionString = "Server = tcp:3.6.73.110, 1433; Database = PI_Testing; User Id = dbdevuser; Password = Sql2020";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT CheckInTime FROM EmployeeTimings4 WHERE full_name = @UserName AND CheckOutTime IS NULL";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserName", userName);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                checkInTime = reader.GetDateTime(0);
                            }
                        }
                    }
                }

                TimeSpan timeDiff = DateTime.Now - checkInTime;
                string totalHoursWorked = $"{timeDiff.Hours}:{timeDiff.Minutes}:{timeDiff.Seconds}";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE EmployeeTimings4 SET CheckOutTime = @CheckOutTime, TotalHoursWorked = @TotalHoursWorked WHERE CheckOutTime IS NULL";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@CheckOutTime", DateTime.Now);
                        command.Parameters.AddWithValue("@TotalHoursWorked", totalHoursWorked);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while saving the check-out time. Please try again later.");
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Name(Employee emp)
        {
            string connectionString = "Server = tcp:3.6.73.110, 1433; Database = PI_Testing; User Id = dbdevuser; Password = Sql2020";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO EmployeeTimings4(full_name) VALUES (@full_name)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {

                    command.Parameters.AddWithValue("@full_name",emp.full_name);
                    command.ExecuteNonQuery();
                }
            }
            return RedirectToAction("Index");

            
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Logout()
        {
            // Clear the user's session and redirect to the login page
            Session.Clear();
            return RedirectToAction("Index", "Login");
        }



    }

}



